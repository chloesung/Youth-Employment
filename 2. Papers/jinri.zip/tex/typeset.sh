#!/bin/bash
latexmk main.tex -pvc -pdfxe -g -gg
#latexmk main.tex -pvc -pdf -g -gg
latexmk main.tex -c
